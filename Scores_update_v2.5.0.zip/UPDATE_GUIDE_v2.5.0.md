# Hướng dẫn cập nhật local lên v2.5.0

Phiên bản này được tạo trực tiếp từ `Scores(1).zip`.

## Nội dung

- Cố định độ rộng từng cặp cột L1/L2 của học phần trong bảng học kỳ.
- Các cột thông tin sinh viên và tổng kết tiếp tục co giãn theo màn hình.
- Bảng năm học tiếp tục tự giãn, chỉ cuộn ngang khi màn hình không đủ rộng.
- Bổ sung thông báo phiên bản mới dưới topbar và nút tải update cho admin.
- Giữ `APP=Microsoft Office` trong kết nối SQL Server.

## Cập nhật dự án đang chạy local

1. Đóng cửa sổ `serve.py`. Nếu vẫn còn chạy, mở Task Manager và kết thúc đúng
   tiến trình Python của dự án.
2. Sao lưu toàn bộ thư mục dự án hiện tại.
3. Giải nén `Scores_update_v2.5.0.zip` vào thư mục dự án và đồng ý ghi đè các
   file trùng tên.
4. Không xóa hoặc thay thế `instance`, `venv`, `backup_tuyensinh.db` và
   `.flask_secret_key`.
5. Không cần chạy lại `setup_ngrok.py`; cấu hình hiện tại vẫn được giữ nguyên.
6. Mở lại `serve.py`, sau đó truy cập `http://127.0.0.1:8000`.
7. Nhấn `Ctrl+F5` để trình duyệt nạp JavaScript/CSS mới.

## Bật thông báo cập nhật

Đặt file manifest trên một địa chỉ HTTPS ổn định. Sau đó thêm vào
`instance/config.json`:

```json
"UPDATE_MANIFEST_URL": "https://ten-mien-cua-ban/update_manifest.json"
```

Nếu chưa có nơi đặt manifest, có thể để trống. Ứng dụng và bản v2.5.0 vẫn hoạt
động bình thường; chỉ chức năng thông báo phiên bản tạm thời chưa bật.

Manifest của phiên bản kế tiếp phải có `version` lớn hơn `2.5.0`. Ví dụ xem
`update_manifest.example.json`.

## Kiểm tra sau cập nhật

1. Đăng nhập bằng tài khoản cũ.
2. Mở `Tính điểm học tập` và chọn một học kỳ có nhiều học phần.
3. Thu nhỏ/phóng rộng cửa sổ: cột L1/L2 không đổi độ rộng; các cột còn lại giãn.
4. Chọn năm học: bảng tổng hợp vẫn giãn theo khung.
5. Kiểm tra xuất Excel và in bảng điểm.
6. Kiểm tra các chức năng còn lại trước khi chép cùng gói update lên máy cơ quan.
