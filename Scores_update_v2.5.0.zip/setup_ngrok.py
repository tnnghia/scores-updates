import getpass
import json
import secrets
from pathlib import Path


PROJECT_DIR = Path(__file__).resolve().parent
CONFIG_PATH = PROJECT_DIR / "instance" / "config.json"
API_CONFIG_PATH = PROJECT_DIR / "instance" / "api_config.json"


def ask(label, default=""):
    suffix = f" [{default}]" if default else ""
    value = input(f"{label}{suffix}: ").strip()
    return value or default


def main():
    print("Tạo cấu hình cục bộ cho Flask/ngrok (không chia sẻ file này).")
    existing = {}
    if CONFIG_PATH.exists():
        existing = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))

    old_password = str(existing.get("DB_PASSWORD") or "")
    password = getpass.getpass(
        "Mật khẩu SQL Server (Enter để giữ mật khẩu hiện tại): "
    ).strip() or old_password

    config = {
        "FLASK_SECRET_KEY": existing.get("FLASK_SECRET_KEY") or secrets.token_hex(32),
        "PUBLIC_HTTPS": ask("Dùng HTTPS true/false", existing.get("PUBLIC_HTTPS", "false")),
        "DB_DRIVER": ask("ODBC driver", existing.get("DB_DRIVER", "SQL Server")),
        "DB_SERVER": ask("SQL Server (IP hoặc tên máy)", existing.get("DB_SERVER", "")),
        "DB_DATABASE": ask("Tên cơ sở dữ liệu", existing.get("DB_DATABASE", "")),
        "DB_USERNAME": ask("Tài khoản SQL Server", existing.get("DB_USERNAME", "")),
        "DB_PASSWORD": password,
        "DB_APP": ask("Tên ứng dụng kết nối", existing.get("DB_APP", "Microsoft Office")),
        "DB_ENCRYPT": ask("Mã hóa kết nối SQL Server yes/no", existing.get("DB_ENCRYPT", "no")),
        "DB_TRUST_SERVER_CERTIFICATE": ask(
            "Tin cậy chứng chỉ máy chủ yes/no",
            existing.get("DB_TRUST_SERVER_CERTIFICATE", "yes"),
        ),
        "UPDATE_MANIFEST_URL": ask(
            "Địa chỉ HTTPS kiểm tra phiên bản (có thể để trống)",
            existing.get("UPDATE_MANIFEST_URL", ""),
        ),
    }

    required = ("DB_SERVER", "DB_DATABASE", "DB_USERNAME", "DB_PASSWORD", "DB_APP")
    missing = [name for name in required if not config[name]]
    if missing:
        raise SystemExit("Thiếu cấu hình: " + ", ".join(missing))

    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(
        json.dumps(config, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    existing_api = {}
    if API_CONFIG_PATH.exists():
        existing_api = json.loads(API_CONFIG_PATH.read_text(encoding="utf-8"))
    token = getpass.getpass("Token API tuyển sinh (Enter để giữ hiện tại): ").strip()
    cookie = getpass.getpass("Cookie API tuyển sinh (Enter để giữ hiện tại): ").strip()
    api_config = {
        "TOKEN": token or str(existing_api.get("TOKEN") or ""),
        "COOKIE": cookie or str(existing_api.get("COOKIE") or ""),
    }
    API_CONFIG_PATH.write_text(
        json.dumps(api_config, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(f"Đã tạo: {CONFIG_PATH}")
    print(f"Đã tạo: {API_CONFIG_PATH}")
    print("Tiếp theo chạy run_all.bat")


if __name__ == "__main__":
    main()
