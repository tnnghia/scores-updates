import os
import json
import secrets
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent
SECRET_FILE = BASE_DIR / ".flask_secret_key"
INSTANCE_CONFIG_FILE = BASE_DIR / "instance" / "config.json"


def load_instance_config():
    """Đọc cấu hình cục bộ; file này không được đóng gói/chia sẻ."""
    if not INSTANCE_CONFIG_FILE.exists():
        return {}
    with INSTANCE_CONFIG_FILE.open("r", encoding="utf-8") as config_file:
        return json.load(config_file)


INSTANCE_CONFIG = load_instance_config()


def setting(name, default=""):
    return os.getenv(name, str(INSTANCE_CONFIG.get(name, default))).strip()


def load_secret_key():
    """Dùng khóa phiên cố định giữa các lần khởi động ứng dụng."""
    environment_key = setting("FLASK_SECRET_KEY")
    if environment_key:
        return environment_key

    if SECRET_FILE.exists():
        saved_key = SECRET_FILE.read_text(encoding="utf-8").strip()
        if saved_key:
            return saved_key

    new_key = secrets.token_hex(32)
    SECRET_FILE.write_text(new_key, encoding="utf-8")
    return new_key


SECRET_KEY = load_secret_key()


def require_setting(name):
    value = setting(name)
    if not value:
        raise RuntimeError(
            f"Thiếu cấu hình {name}. Hãy chạy: python setup_ngrok.py"
        )
    return value


DB_CONN = (
    f"DRIVER={{{setting('DB_DRIVER', 'SQL Server')}}};"
    f"SERVER={require_setting('DB_SERVER')};"
    f"DATABASE={require_setting('DB_DATABASE')};"
    f"UID={require_setting('DB_USERNAME')};"
    f"PWD={require_setting('DB_PASSWORD')};"
    f"APP={setting('DB_APP', 'Microsoft Office')};"
    f"Encrypt={setting('DB_ENCRYPT', 'no')};"
    f"TrustServerCertificate={setting('DB_TRUST_SERVER_CERTIFICATE', 'yes')};"
)

PUBLIC_HTTPS = setting("PUBLIC_HTTPS", "true").lower() in {"1", "true", "yes", "on"}
APP_VERSION = "2.5.0"
UPDATE_MANIFEST_URL = setting("UPDATE_MANIFEST_URL")
