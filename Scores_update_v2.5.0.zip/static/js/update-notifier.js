document.addEventListener('DOMContentLoaded', async () => {
  const banner = document.getElementById('appUpdateBanner');
  if (!banner) return;

  try {
    const response = await fetch('/api/update/status', {
      credentials: 'same-origin',
      headers: { Accept: 'application/json' }
    });
    if (!response.ok) return;

    const status = await response.json();
    if (!status.success || !status.enabled || !status.update_available) return;

    const dismissKey = `dismissed-update-${status.latest_version}`;
    if (localStorage.getItem(dismissKey) === '1') return;

    document.getElementById('appUpdateTitle').textContent =
      `${status.title || 'Có phiên bản mới'} – v${status.latest_version}`;
    document.getElementById('appUpdateDescription').textContent =
      status.description || `Phiên bản hiện tại: v${status.current_version}`;

    const notes = document.getElementById('appUpdateNotes');
    if (status.release_notes_url?.startsWith('https://')) {
      notes.href = status.release_notes_url;
      notes.hidden = false;
    }

    const updateButton = document.getElementById('appUpdateDownload');
    if (status.can_update && status.download_url?.startsWith('https://')) {
      updateButton.hidden = false;
      updateButton.addEventListener('click', () => {
        const confirmed = window.confirm(
          `Tải phiên bản v${status.latest_version}?\n\n` +
          'Sau khi tải: đóng serve.py, sao lưu dự án, giữ nguyên instance và backup_tuyensinh.db, rồi mới chép gói update.'
        );
        if (confirmed) window.open(status.download_url, '_blank', 'noopener');
      });
    }

    document.getElementById('appUpdateDismiss').addEventListener('click', () => {
      localStorage.setItem(dismissKey, '1');
      banner.hidden = true;
    });

    banner.hidden = false;
  } catch (error) {
    console.debug('Không kiểm tra được phiên bản cập nhật.', error);
  }
});
