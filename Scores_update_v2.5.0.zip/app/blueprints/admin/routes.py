import sqlite3
import time
from urllib.parse import urlparse

import requests
from flask import Blueprint, jsonify, request, send_file, session

from app.common.auth import roles_required
from app.common.paths import PROJECT_ROOT, SQLITE_DB_PATH
from config import APP_VERSION, UPDATE_MANIFEST_URL
from web_api import load_api_headers, session_api

bp = Blueprint("admin", __name__)
_update_cache = {"checked_at": 0.0, "manifest": None}


def _version_tuple(value):
    result = []
    for part in str(value or "0").strip().lstrip("vV").split(".")[:3]:
        digits = "".join(character for character in part if character.isdigit())
        result.append(int(digits or 0))
    return tuple((result + [0, 0, 0])[:3])


def _https_url(value):
    parsed = urlparse(str(value or ""))
    return parsed.scheme == "https" and bool(parsed.netloc)


def get_update_status():
    result = {
        "success": True,
        "enabled": bool(UPDATE_MANIFEST_URL),
        "current_version": APP_VERSION,
        "update_available": False,
        "can_update": session.get("role") == "admin",
    }

    if not UPDATE_MANIFEST_URL:
        return jsonify(result)
    if not _https_url(UPDATE_MANIFEST_URL):
        return jsonify({**result, "enabled": False, "message": "URL cập nhật phải dùng HTTPS."})

    try:
        now = time.time()
        if not _update_cache["manifest"] or now - _update_cache["checked_at"] > 900:
            response = requests.get(UPDATE_MANIFEST_URL, timeout=6)
            response.raise_for_status()
            manifest = response.json()
            if not str(manifest.get("version") or "").strip():
                raise ValueError("Manifest thiếu version.")
            if not _https_url(manifest.get("download_url")):
                raise ValueError("Manifest thiếu download_url HTTPS.")
            _update_cache.update({"checked_at": now, "manifest": manifest})

        manifest = _update_cache["manifest"]
        latest_version = str(manifest.get("version")).strip()
        return jsonify({
            **result,
            "latest_version": latest_version,
            "update_available": _version_tuple(latest_version) > _version_tuple(APP_VERSION),
            "title": str(manifest.get("title") or "Có phiên bản mới"),
            "description": str(manifest.get("description") or ""),
            "download_url": str(manifest.get("download_url")),
            "release_notes_url": str(manifest.get("release_notes_url") or ""),
            "sha256": str(manifest.get("sha256") or ""),
        })
    except Exception:
        return jsonify({**result, "message": "Tạm thời chưa kiểm tra được phiên bản mới."})


def luu_backup_tu_trinh_duyet():
    try:
        req_data = request.json
        if not req_data or 'list_matsxt' not in req_data:
            res = jsonify({"status": "error", "message": "Thiếu danh sách list_matsxt!"})
            return res, 400

        list_matsxt = req_data['list_matsxt']
        
        conn_sqlite = sqlite3.connect(SQLITE_DB_PATH)
        cursor_sqlite = conn_sqlite.cursor()
        headers = load_api_headers()
        count_success = 0

        print(f"\n🚀 [SQLITE CO LẬP] Quét ngầm 52 cột gốc cho {len(list_matsxt)} mã thí sinh...")

        for matsxt in list_matsxt:
            matsxt = str(matsxt).strip()
            if not matsxt: continue
                
            url = f"https://camauvkc.edu.vn/qldt/api/qdt/admissions/applicant/{matsxt}"
            try:
                response = session_api.get(url, headers=headers, timeout=10, verify=False)
                if response.status_code == 200:
                    src = response.json()
                    if not src or "message" in src: continue
                    
                    # Hàm chuẩn hóa giá trị từ JSON trường (Xử lý bọc mảng và ép kiểu bit 1/0)
                    def get_clean_val(key, is_bit=False):
                        val = src.get(key, "")
                        if isinstance(val, list) and len(val) > 0: val = val[0]
                        if is_bit:
                            return 1 if val is True or str(val).lower() in ['1', 'true', 'v'] else 0
                        return str(val).strip() if val is not None else ""

                    # Xóa gối đầu dựa trên khóa chính duy nhất MaTSXT
                    cursor_sqlite.execute("DELETE FROM ThisinhBackupGoc WHERE MaTSXT = ?", (matsxt,))
                    
                    # Đổ chuẩn xác dữ liệu cho đúng 53 trường thông tin vào SQLite
                    val_list = [
                        matsxt,
                        get_clean_val('hs1', is_bit=True), get_clean_val('hs2', is_bit=True),
                        get_clean_val('hs3', is_bit=True), get_clean_val('hs4', is_bit=True),
                        get_clean_val('hs5', is_bit=True), get_clean_val('hs6', is_bit=True),
                        get_clean_val('hs7', is_bit=True), get_clean_val('hs8', is_bit=True),
                        get_clean_val('hs9', is_bit=True), get_clean_val('hs10', is_bit=True),
                        get_clean_val('hs11', is_bit=True), get_clean_val('hs12', is_bit=True),
                        get_clean_val('hs13'), get_clean_val('hs14', is_bit=True),
                        get_clean_val('hs15', is_bit=True), get_clean_val('hs16', is_bit=True),
                        get_clean_val('GhiChu'), get_clean_val('NopOnline', is_bit=True),
                        get_clean_val('MaTiepCan'), get_clean_val('SoDT'), get_clean_val('NguoiNhan'),
                        get_clean_val('NgayNhan'), get_clean_val('NguoiSua'), get_clean_val('NgaySua'),
                        get_clean_val('LPsochungtu'), get_clean_val('LPsotien'), get_clean_val('LPnoidungthu'),
                        get_clean_val('LPnguoinop'), get_clean_val('LPnguoithu'), get_clean_val('LPngaythu'),
                        get_clean_val('LPviettelPay'), get_clean_val('XLhanhkiem'), get_clean_val('NguoiXT'),
                        get_clean_val('NgayXT'), get_clean_val('RaSoat'), get_clean_val('NguoiRasoat'),
                        get_clean_val('NgayRasoat'), get_clean_val('Mon1'), get_clean_val('Mon2'),
                        get_clean_val('Mon3'), get_clean_val('DiemUT'), get_clean_val('DiemXT'),
                        get_clean_val('Tuyenthang'), get_clean_val('DongPhuc_SL'), get_clean_val('DongPhuc_Tien'),
                        get_clean_val('DoGDTC_SL'), get_clean_val('DoGDTC_Tien'), get_clean_val('BHtoandien_Tien'),
                        get_clean_val('KhamSK_Tien'), get_clean_val('Nguoithu_LPnhaphoc'), get_clean_val('Ngaythu_LPnhaphoc'),
                        get_clean_val('NoidungThu_LPnhaphoc'), get_clean_val('LinkHoso')
                    ]
                    
                    placeholders = ",".join(["?"] * len(val_list))
                    cursor_sqlite.execute(f"INSERT INTO ThisinhBackupGoc VALUES ({placeholders})", val_list)
                    count_success += 1
                    print(f"   ✅ [SQLite] Đã lưu trọn vẹn 52 cột gốc cho mã: {matsxt}")
                else:
                    print(f"   ❌ Mã {matsxt} thất bại (Status: {response.status_code})")
            except Exception as e:
                print(f"   ❌ Lỗi kết nối mã {matsxt}: {e}")
            time.sleep(0.3)

        conn_sqlite.commit()
        conn_sqlite.close()
        
        res = jsonify({"status": "success", "count": count_success})
        return res, 200
    except Exception as e:
        print(f"❌ Lỗi: {e}")
        res = jsonify({"status": "error", "message": str(e)})
        return res, 500

def tai_excel_goc_52_cot():
    try:
        import pandas as pd
        conn = sqlite3.connect(SQLITE_DB_PATH)
        df = pd.read_sql_query("SELECT * FROM ThisinhBackupGoc", conn)
        conn.close()
        
        if df.empty:
            return "<h3>📊 Kho dữ liệu hiện đang trống!</h3>"

        ngay_thang = time.strftime("%d_%m_%Y")
        file_name = f"Backup_Goc_TuyenSinh_CamauVKC_{ngay_thang}.xlsx"
        excel_output_path = str(PROJECT_ROOT / file_name)
        
        with pd.ExcelWriter(excel_output_path, engine='openpyxl') as writer:
            df.to_excel(writer, index=False, sheet_name="Dữ Liệu Tuyển Sinh")
        
        from flask import send_file
        return send_file(excel_output_path, as_attachment=True)
    except Exception as e:
        return f"❌ Lỗi xuất Excel: {e}"

def get_system_logs():
    conn = sqlite3.connect(SQLITE_DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    # Lấy 500 bản ghi mới nhất xếp lên đầu
    cursor.execute("SELECT * FROM UsersLogs ORDER BY created_at DESC LIMIT 500")
    logs = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return jsonify({"success": True, "logs": logs})


# Các chức năng trong Blueprint này chỉ dành cho quản trị viên.
luu_backup_tu_trinh_duyet = roles_required("admin")(luu_backup_tu_trinh_duyet)
tai_excel_goc_52_cot = roles_required("admin")(tai_excel_goc_52_cot)
get_system_logs = roles_required("admin")(get_system_logs)

bp.add_url_rule('/api/save-browser-backup', endpoint='luu_backup_tu_trinh_duyet', view_func=luu_backup_tu_trinh_duyet, methods=['POST'])
bp.add_url_rule('/download-excel-goc', endpoint='tai_excel_goc_52_cot', view_func=tai_excel_goc_52_cot)
bp.add_url_rule('/api/admin/logs', endpoint='get_system_logs', view_func=get_system_logs, methods=['GET'])
bp.add_url_rule('/api/update/status', endpoint='get_update_status', view_func=get_update_status, methods=['GET'])
