// Khai báo biến global để các hàm dùng chung
let elResult;
let currentHocKyData = [];
let currentMaHK = null;
let currentNamHocData = [];
let currentMaNH = null;
let listQuyetDinh = [];
let listHocky = [];

document.addEventListener('DOMContentLoaded', function () {
    const elKhoa = document.getElementById('filter_khoa_studyscore');
    const elLop = document.getElementById('filter_lop_studyscore');
    const elHk = document.getElementById('filter_hk_studyscore');
    elResult = document.getElementById('StudyscoreResult');

    // Hàm bổ trợ định dạng 1 số lẻ
    const formatDiem = (val) => {
        if (val === null || val === undefined || val === '') return '-';
        if (isNaN(val)) return val; // Trả về chữ (M, Chuyển điểm...)
        return parseFloat(val).toFixed(1);
    };
	
	// Thêm hàm này vào đầu file hoặc trong DOMContentLoaded
	function formatNgaySinh(val) {
		if (!val || val === '') return '';
		
		// Nếu là dạng số (Serial Date của Excel bị lỗi)
		if (!isNaN(val) && val.toString().includes('.')) {
			// Chuyển từ Serial Date sang Object Date của JS
			const date = new Date(Math.round((val - 25569) * 86400 * 1000));
			const d = String(date.getDate()).padStart(2, '0');
			const m = String(date.getMonth() + 1).padStart(2, '0');
			const y = date.getFullYear();
			return `${d}/${m}/${y}`;
		}

		// Nếu là chuỗi có chứa giờ (dd/mm/yyyy hh:mm:ss)
		let datePart = val.toString().split(' ')[0];
		
		// Kiểm tra nếu phần ngày có dấu gạch ngang (yyyy-mm-dd) thì chuyển về dd/mm/yyyy
		if (datePart.includes('-')) {
			const parts = datePart.split('-');
			if (parts[0].length === 4) { // yyyy-mm-dd
				return `${parts[2]}/${parts[1]}/${parts[0]}`;
			}
		}
		
		return datePart;
	}

    // 1. Load Khóa
    fetch('/api/khoa')
        .then(res => res.json())
        .then(data => {
            elKhoa.innerHTML = '<option value="">-- Chọn Khóa --</option>';
            data.forEach(k => {
                elKhoa.innerHTML += `<option value="${k}">${k}</option>`;
            });
        });

    // 2. Event: Chọn Khóa
    elKhoa.addEventListener('change', function () {
        const khoa = this.value;
        elLop.disabled = !khoa;
        elHk.disabled = !khoa;

        if (khoa) {
            elLop.innerHTML = '<option>Đang tải...</option>';
            fetch(`/api/lop_by_khoa/${khoa}`)
                .then(res => res.json())
                .then(data => {
                    elLop.innerHTML = '<option value="">-- Chọn Lớp --</option>';
                    data.forEach(l => {
                        elLop.innerHTML += `<option value="${l.MaL}">${l.Tenlop}</option>`;
                    });
                });

            fetch(`/api/hocky/by-khoa?khoa=${khoa}`)
                .then(res => res.json())
                .then(data => {
                    elHk.innerHTML = '<option value="">-- Chọn Học kỳ --</option>';
                    data.forEach(h => {
                        elHk.innerHTML += `<option value="${h.ma}">${h.ten}</option>`;
                    });
                });
        }
    });

    // 3. Event: Chọn Lớp/Học kỳ
    [elLop, elHk].forEach(el => {
        el.addEventListener('change', () => {
            if (elLop.value && elHk.value) window.loadDiem(elLop.value, elHk.value);
        });
    });

    // ĐƯA HÀM NÀY RA NGOÀI (HOẶC GÁN VÀO WINDOW)
	/* window.loadDiem = function(lop, hk) {
		const elResult = document.getElementById('StudyscoreResult');
		elResult.innerHTML = '<div class="md-muted">Đang tính toán...</div>';
		fetch(`/api/diem/hocky?lop=${lop}&hocky=${hk}`)
			.then(res => res.json())
			.then(res => renderTable(res));
	}; */
	
	window.loadDiem = async function (lop, hk) {
		const elResult = document.getElementById('StudyscoreResult');

		if (!elResult) {
			console.error("Không tìm thấy StudyscoreResult");
			return;
		}

		elResult.innerHTML = `
			<div class="md-muted">
				<i class="fas fa-spinner fa-spin"></i>
				Đang tính toán dữ liệu...
			</div>
		`;

		currentHocKyData = [];
		currentMaHK = null;

		try {
			let apiUrl = "";
			let renderFunction = null;

			// =============================================
			// 1. ĐIỂM TOÀN KHÓA
			// =============================================
			if (hk === "TK") {
				apiUrl = `/api/diem/toan-khoa?lop=${encodeURIComponent(lop)}`;
				renderFunction = renderTableToanKhoa;
			}

			// =============================================
			// 2. ĐIỂM NĂM HỌC
			// Mã năm học gồm đúng 2 chữ số: 25, 26...
			// =============================================
			else if (/^\d{2}$/.test(hk)) {
				apiUrl =
					`/api/diem/nam-hoc` +
					`?lop=${encodeURIComponent(lop)}` +
					`&namhoc=${encodeURIComponent(hk)}`;

				renderFunction = renderTableNamHoc;
			}

			// =============================================
			// 3. ĐIỂM HỌC KỲ
			// Mã học kỳ gồm 3 chữ số: 251, 252...
			// =============================================
			else {
				apiUrl =
					`/api/diem/hocky` +
					`?lop=${encodeURIComponent(lop)}` +
					`&hocky=${encodeURIComponent(hk)}`;

				renderFunction = renderTable;
			}

			const response = await fetch(apiUrl);

			let result;

			try {
				result = await response.json();
			} catch (jsonError) {
				throw new Error(
					`API không trả về JSON hợp lệ. HTTP ${response.status}`
				);
			}

			if (!response.ok) {
				throw new Error(
					result.message ||
					result.error ||
					`Lỗi HTTP ${response.status}`
				);
			}

			if (result.success === false) {
				throw new Error(
					result.message || "Không thể tải dữ liệu."
				);
			}

			// Chỉ học kỳ mới được phép lưu TongketHK
			if (/^\d{3}$/.test(hk)) {
				currentHocKyData = Array.isArray(result.data)
					? result.data
					: [];

				currentMaHK = hk;
			}
			else if (/^\d{2}$/.test(hk)) {
				currentNamHocData = Array.isArray(result.data)
					? result.data
					: [];

				currentMaNH = hk;
			}
			
			renderFunction(result);

		} catch (error) {
			console.error("Lỗi loadDiem:", error);

			elResult.innerHTML = `
				<div
					style="
						padding:15px;
						color:#b71c1c;
						background:#ffebee;
						border:1px solid #ef9a9a;
						border-radius:5px;
					"
				>
					<b>Không thể tải dữ liệu.</b><br>
					${error.message}
				</div>
			`;
		}
	};
	
	function renderTable(res) {
		const elResult = document.getElementById('StudyscoreResult');
		const elLop = document.getElementById('filter_lop_studyscore');
		const elHk = document.getElementById('filter_hk_studyscore');
		
		if (!res || !res.data || res.data.length === 0) {
			elResult.innerHTML = '<div class="md-muted">Không có dữ liệu sinh viên cho lớp và học kỳ này.</div>';
			return;
		}

		const formatDiem = (val) => {
			if (val === null || val === undefined || val === '') return '';
			return isNaN(val) ? val : parseFloat(val).toFixed(1);
		};
		
		const formatDTB = (val) => {
			if (val === null || val === undefined || val === '') return '';
			return isNaN(val) ? val : parseFloat(val).toFixed(2);
		};

		// UI: Sử dụng Flexbox cho các nút bấm giống image_344bb2.png
		let html = `
			<div class="md-table-actions no-print" style="margin-bottom: 15px; display: flex; gap: 10px;">
				<button class="md-btn md-btn-green" onclick="exportToExcel()" style="background-color: #28a745; color: white; border: none; padding: 8px 15px; border-radius: 4px; cursor: pointer;">
					<i class="fas fa-file-excel"></i> Xuất Excel
				</button>
				<button class="md-btn md-btn-blue" onclick="printBangDiem()" style="background-color: #007bff; color: white; border: none; padding: 8px 15px; border-radius: 4px; cursor: pointer;">
					<i class="fas fa-print"></i> In bảng điểm
				</button>
				<button class="md-btn" style="background: #673ab7; color: white;" onclick="openEditCTDT()">
					<i class="fas fa-edit"></i> Xem/Sửa CTĐT
				</button>
				<button 
				id="btnSaveHocKy"
				class="md-btn"
				style="background:#e67e22;color:white; position:relative; min-width:150px;"
				onclick="saveHocky()"
				>
				<span class="btn-text">
					<i class="fas fa-save"></i> Lưu điểm học kỳ
				</span>
				<span class="btn-spinner" style="display:none;">
					<i class="fas fa-spinner fa-spin"></i> Đang lưu...
				</span>
				</button>
				<div class="md-table-actions no-print" style="margin-bottom: 15px; display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
					<div class="filter-group" style="display: flex; align-items: center; height: 36px; background: #fff; border: 1px solid #ccc; border-radius: 4px; position: relative;">
						<span style="background: #f8f9fa; height: 100%; display: flex; align-items: center; padding: 0 12px; border-right: 1px solid #ccc; font-weight: bold; font-size: 13px; color: #555;">
							Lọc tình trạng:
						</span>
						<div style="display: flex; gap: 15px; padding: 0 15px; align-items: center; font-size: 13px;">
							<label style="display: flex; align-items: center; gap: 5px; cursor: pointer;">
								<input type="checkbox" class="filter-status" value="0" checked onchange="window.filterByStatus()"> Đang học
							</label>
							<label style="display: flex; align-items: center; gap: 5px; cursor: pointer;">
								<input type="checkbox" class="filter-status" value="1" onchange="window.filterByStatus()"> Bảo lưu
							</label>
							<label style="display: flex; align-items: center; gap: 5px; cursor: pointer;">
								<input type="checkbox" class="filter-status" value="2" onchange="window.filterByStatus()"> Thôi học
							</label>
							<label style="display: flex; align-items: center; gap: 5px; cursor: pointer;">
								<input type="checkbox" class="filter-status" value="3" onchange="window.filterByStatus()"> Tốt nghiệp
							</label>
						</div>
					</div>
				</div>
				
			</div>
			
			<div class="table-responsive study-score-table-wrap" style="overflow-x: auto;">
				<table class="md-table study-score-table study-score-semester" id="tableStudyScore" style="--study-subject-count:${res.mon.length}; width: 100%; border-collapse: collapse; font-family: Arial, sans-serif; font-size: 13px;">
					<colgroup>
						<col class="study-flex-col study-col-tt">
						<col class="study-flex-col study-col-code">
						<col class="study-flex-col study-col-name">
						<col class="study-flex-col study-col-gender">
						<col class="study-flex-col study-col-birth">
						${res.mon.map(() => `
							<col class="study-subject-col">
							<col class="study-subject-col">
						`).join('')}
						${Array.from({ length: 8 }, () => '<col class="study-flex-col">').join('')}
					</colgroup>
					<thead>
						<tr style="background-color: #f8f9fa;">
							<th rowspan="2" style="border: 1px solid #ddd; width: 40px; padding: 8px;">TT</th>
							<th rowspan="2" style="border: 1px solid #ddd; width: 40px; padding: 20px;">Mã số</th>
							<th rowspan="2" style="border: 1px solid #ddd; min-width: 80px; padding: 8px;">Họ tên</th>
							<th rowspan="2" style="border: 1px solid #ddd; width: 70px; padding: 8px;">Giới tính</th>
							<th rowspan="2" style="border: 1px solid #ddd; width: 100px; padding: 8px;">Ngày sinh</th>
							${res.mon.map(m => `
								<th colspan="2" class="study-subject-heading" style="border: 1px solid #ddd; padding: 4px;">
									<div style="font-size: 11px; font-weight: bold; text-align: center;">${m.ten}</div>
									<div style="font-size: 10px; font-weight: normal; text-align: center;">(${m.tc} TC)</div>
								</th>
							`).join('')}
							<th rowspan="2" style="border: 1px solid #ddd; width: 50px; padding: 4px;">Chưa đạt</th>
							<th rowspan="2" style="border: 1px solid #ddd; width: 50px; padding: 4px;">Thi lại</th>
							<th rowspan="2" style="border: 1px solid #ddd; width: 50px; padding: 4px;">ĐTB</th>
							<th rowspan="2" style="border: 1px solid #ddd; width: 80px; padding: 4px;">Xếp loại</th>
							<th rowspan="2" style="border: 1px solid #ddd; width: 60px; padding: 4px;">Điểm RL</th>
							<th rowspan="2" style="border: 1px solid #ddd; width: 70px; padding: 4px;">XL RL</th>
							<th rowspan="2" style="border: 1px solid #ddd; width: 50px; padding: 4px;">ĐHB</th>
							<th rowspan="2" style="border: 1px solid #ddd; width: 70px; padding: 4px;">XL HB</th>
						</tr>
						<tr style="background-color: #f8f9fa;">
							${res.mon.map(() => `
								<th class="study-subject-score" style="border: 1px solid #ddd; padding: 4px; font-size: 11px;">L1</th>
								<th class="study-subject-score" style="border: 1px solid #ddd; padding: 4px; font-size: 11px;">L2</th>
							`).join('')}
						</tr>
					</thead>
					<tbody>
						${res.data.map((sv, i) => {
							const stt = (sv.tinhtrang !== undefined) ? sv.tinhtrang : (sv.tinhtrang !== undefined ? sv.tinhtrang : 0);
							return `
							<tr data-status="${stt}" style="border-bottom: 1px solid #eee;">
								<td class="row-tt" style="border: 1px solid #ddd; text-align: center; padding: 6px;">${i + 1}</td>
								<td style="border: 1px solid #ddd; text-align: center; padding: 6px; white-space: nowrap;">${sv.masv}</td>								
								<td style="border: 1px solid #ddd; text-align: left; padding: 6px; white-space: nowrap;">${sv.hoten}</td>
								<td style="border: 1px solid #ddd; text-align: center; padding: 6px;">${sv.gioitinh === true || sv.gioitinh === 1 ? 'Nữ' : 'Nam'}</td>
								<td style="border: 1px solid #ddd; text-align: center; padding: 6px;">${formatNgaySinh(sv.ngaysinh)}</td>
								${res.mon.map(m => {
									const d = sv.mon[m.ma] || {};
									return `
										<td class="study-subject-score" style="border: 1px solid #ddd; text-align: center; padding: 6px; ${d.L1 < 5 && d.L1 !== null ? 'color: red; font-weight: bold;' : ''}">${formatDiem(d.L1)}</td>
										<td class="study-subject-score" style="border: 1px solid #ddd; text-align: center; padding: 6px; ${d.L2 < 5 && d.L2 !== null ? 'color: red; font-weight: bold;' : ''}">${formatDiem(d.L2)}</td>
									`;
								}).join('')}
								<td style="border: 1px solid #ddd; text-align: center; padding: 6px;">${sv.chua_dat || 0}</td>
								<td style="border: 1px solid #ddd; text-align: center; padding: 6px;">${sv.thi_lai || 0}</td>
								<td style="border: 1px solid #ddd; text-align: center; padding: 6px; font-weight: bold;">${formatDTB(sv.dtb)}</td>
								<td class="col-xeploai" style="border: 1px solid #ddd; text-align: center; padding: 6px;">${sv.xl_ht || ''}</td>
								<td style="border: 1px solid #ddd; text-align: center; padding: 6px;">${sv.diem_rl || ''}</td>
								<td style="border: 1px solid #ddd; text-align: center; padding: 6px;">${sv.xl_rl || ''}</td>
								<td style="border: 1px solid #ddd; text-align: center; padding: 6px; font-weight: bold;">${formatDTB(sv.dhb)}</td>
								<td style="border: 1px solid #ddd; text-align: center; padding: 6px;">${sv.xl_hb || ''}</td>
							</tr>`;
						}).join('')}
					</tbody>
				</table>
			</div>
		`;

		elResult.innerHTML = html;
		window.filterByStatus();
	}
	
	function renderTableNamHoc(res) {
		const elResult = document.getElementById('StudyscoreResult');

		if (!elResult) return;

		if (!res || !Array.isArray(res.data) || res.data.length === 0) {
			elResult.innerHTML = `
				<div class="md-muted">
					Không có dữ liệu sinh viên cho năm học này.
				</div>
			`;
			return;
		}

		const formatDTB = value => {
			if (
				value === null ||
				value === undefined ||
				value === ""
			) {
				return "";
			}

			const number = Number(value);

			return Number.isFinite(number)
				? number.toFixed(2)
				: value;
		};

		const formatRL = value => {
			if (
				value === null ||
				value === undefined ||
				value === ""
			) {
				return "";
			}

			const number = Number(value);

			return Number.isFinite(number)
				? number.toFixed(1)
				: value;
		};

		const renderTinhTrang = value => {
			const map = {
				0: "Đang học",
				1: "Bảo lưu",
				2: "Thôi học",
				3: "Tốt nghiệp"
			};

			return map[Number(value)] || "";
		};

		const html = `
			<div
				class="md-table-actions no-print"
				style="
					margin-bottom:15px;
					display:flex;
					gap:10px;
					align-items:center;
					flex-wrap:wrap;
				"
			>
				<button
					class="md-btn md-btn-green"
					onclick="exportToExcel()"
					style="
						background:#28a745;
						color:white;
						border:none;
						padding:8px 15px;
						border-radius:4px;
						cursor:pointer;
					"
				>
					<i class="fas fa-file-excel"></i>
					Xuất Excel
				</button>

				<button
					class="md-btn md-btn-blue"
					onclick="printBangDiem(false)"
					style="
						background:#007bff;
						color:white;
						border:none;
						padding:8px 15px;
						border-radius:4px;
						cursor:pointer;
					"
				>
					<i class="fas fa-print"></i>
					In bảng tổng hợp năm học
				</button>
				
				<button
					id="btnSaveNamHoc"
					class="md-btn"
					style="
						background:#e67e22;
						color:white;
						border:none;
						padding:8px 15px;
						border-radius:4px;
						cursor:pointer;
						min-width:160px;
					"
					onclick="saveNamHoc()"
				>
					<span class="btn-text">
						<i class="fas fa-save"></i>
						Lưu điểm năm học
					</span>

					<span class="btn-spinner" style="display:none;">
						<i class="fas fa-spinner fa-spin"></i>
						Đang lưu...
					</span>
				</button>

				<div
					class="filter-group"
					style="
						display:flex;
						align-items:center;
						min-height:36px;
						background:#fff;
						border:1px solid #ccc;
						border-radius:4px;
					"
				>
					<span
						style="
							background:#f8f9fa;
							align-self:stretch;
							display:flex;
							align-items:center;
							padding:0 12px;
							border-right:1px solid #ccc;
							font-weight:bold;
							font-size:13px;
							color:#555;
						"
					>
						Lọc tình trạng:
					</span>

					<div
						style="
							display:flex;
							gap:15px;
							padding:8px 15px;
							align-items:center;
							flex-wrap:wrap;
							font-size:13px;
						"
					>
						<label>
							<input
								type="checkbox"
								class="filter-status"
								value="0"
								checked
								onchange="window.filterByStatus()"
							>
							Đang học
						</label>

						<label>
							<input
								type="checkbox"
								class="filter-status"
								value="1"
								onchange="window.filterByStatus()"
							>
							Bảo lưu
						</label>

						<label>
							<input
								type="checkbox"
								class="filter-status"
								value="2"
								onchange="window.filterByStatus()"
							>
							Thôi học
						</label>

						<label>
							<input
								type="checkbox"
								class="filter-status"
								value="3"
								onchange="window.filterByStatus()"
							>
							Tốt nghiệp
						</label>
					</div>
				</div>
			</div>

			<div
				class="table-responsive study-score-table-wrap"
				style="overflow-x:auto;"
			>
				<table
					class="md-table study-score-table study-score-year"
					id="tableStudyScore"
					style="
						width:100%;
						border-collapse:collapse;
						font-family:Arial, sans-serif;
						font-size:13px;
					"
				>
					<thead>
						<tr style="background:#f8f9fa;">
							<th style="border:1px solid #ddd;padding:8px;width:40px;">
								TT
							</th>

							<th style="border:1px solid #ddd;padding:8px;width:100px;">
								Mã số
							</th>

							<th style="border:1px solid #ddd;padding:8px;min-width:180px;">
								Họ tên
							</th>

							<th style="border:1px solid #ddd;padding:8px;width:70px;">
								Giới tính
							</th>

							<th style="border:1px solid #ddd;padding:8px;width:100px;">
								Ngày sinh
							</th>

							<th style="border:1px solid #ddd;padding:8px;width:65px;">
								Chưa đạt
							</th>

							<th style="border:1px solid #ddd;padding:8px;width:65px;">
								Thi lại
							</th>

							<th style="border:1px solid #ddd;padding:8px;width:65px;">
								ĐTB năm
							</th>

							<th style="border:1px solid #ddd;padding:8px;width:90px;">
								Xếp loại học tập
							</th>

							<th style="border:1px solid #ddd;padding:8px;width:70px;">
								Điểm RL năm
							</th>

							<th style="border:1px solid #ddd;padding:8px;width:90px;">
								Xếp loại RL
							</th>

							<th style="border:1px solid #ddd;padding:8px;width:70px;">
								ĐHB năm
							</th>

							<th style="border:1px solid #ddd;padding:8px;width:90px;">
								Xếp loại HB
							</th>
						</tr>
					</thead>

					<tbody>
						${res.data.map((sv, index) => {
							const tinhTrang =
								sv.tinhtrang !== null &&
								sv.tinhtrang !== undefined
									? Number(sv.tinhtrang)
									: 0;

							return `
								<tr
									data-status="${tinhTrang}"
									style="border-bottom:1px solid #eee;"
								>
									<td
										class="row-tt"
										style="
											border:1px solid #ddd;
											text-align:center;
											padding:6px;
										"
									>
										${index + 1}
									</td>

									<td
										style="
											border:1px solid #ddd;
											text-align:center;
											padding:6px;
											white-space:nowrap;
										"
									>
										${sv.masv || ""}
									</td>

									<td
										style="
											border:1px solid #ddd;
											text-align:left;
											padding:6px;
											white-space:nowrap;
										"
									>
										${sv.hoten || ""}
									</td>

									<td
										style="
											border:1px solid #ddd;
											text-align:center;
											padding:6px;
										"
									>
										${
											sv.gioitinh === true ||
											sv.gioitinh === 1
												? "Nữ"
												: "Nam"
										}
									</td>

									<td
										style="
											border:1px solid #ddd;
											text-align:center;
											padding:6px;
										"
									>
										${formatNgaySinh(sv.ngaysinh)}
									</td>

									<td
										style="
											border:1px solid #ddd;
											text-align:center;
											padding:6px;
											${
												Number(sv.chua_dat || 0) > 0
													? "color:#d32f2f;font-weight:bold;"
													: ""
											}
										"
									>
										${sv.chua_dat || 0}
									</td>

									<td
										style="
											border:1px solid #ddd;
											text-align:center;
											padding:6px;
											${
												Number(sv.thi_lai || 0) > 0
													? "color:#d32f2f;font-weight:bold;"
													: ""
											}
										"
									>
										${sv.thi_lai || 0}
									</td>

									<td
										style="
											border:1px solid #ddd;
											text-align:center;
											padding:6px;
											font-weight:bold;
										"
									>
										${formatDTB(sv.dtb)}
									</td>

									<td
										class="col-xeploai"
										style="
											border:1px solid #ddd;
											text-align:center;
											padding:6px;
										"
									>
										${sv.xl_ht || ""}
									</td>

									<td
										style="
											border:1px solid #ddd;
											text-align:center;
											padding:6px;
										"
									>
										${sv.diem_rl}
									</td>

									<td
										style="
											border:1px solid #ddd;
											text-align:center;
											padding:6px;
										"
									>
										${sv.xl_rl || ""}
									</td>

									<td
										style="
											border:1px solid #ddd;
											text-align:center;
											padding:6px;
											font-weight:bold;
										"
									>
										${formatDTB(sv.dhb)}
									</td>

									<td
										style="
											border:1px solid #ddd;
											text-align:center;
											padding:6px;
										"
									>
										${sv.xl_hb || ""}
									</td>
								</tr>
							`;
						}).join("")}
					</tbody>
				</table>
			</div>
		`;

		elResult.innerHTML = html;

		if (typeof window.filterByStatus === "function") {
			window.filterByStatus();
		}
	}
	
	
	function renderTableToanKhoa(res) {
		const elResult = document.getElementById('StudyscoreResult');
		
		if (!res || !res.data || res.data.length === 0) {
			elResult.innerHTML = '<div class="md-muted">Không có dữ liệu tích lũy cho lớp này.</div>';
			return;
		}

		let html = `
			<div class="md-table-actions no-print" style="margin-bottom: 15px; display: flex; gap: 10px;">
				<button class="md-btn md-btn-green" onclick="exportToExcel()" style="background-color: #28a745; color: white; border: none; padding: 8px 15px; border-radius: 4px; cursor: pointer;">
					<i class="fas fa-file-excel"></i> Xuất Excel Tốt Nghiệp
				</button>
				<button class="md-btn md-btn-blue" onclick="printBangDiem(true)" style="background-color: #007bff; color: white; border: none; padding: 8px 15px; border-radius: 4px; cursor: pointer;">
					<i class="fas fa-print"></i> In danh sách xét TN
				</button>
				<button class="md-btn md-btn-orange" onclick="xettotnghiep(this)" style="background:#e67e22;color:white" >
					<i class="fas fa-save"></i> Xét tốt nghiệp
				<button class="md-btn" style="background:#2ecc71;color:white" onclick="congnhantotnghiep()">
					<i class="fas fa-check-circle"></i> Công nhận tốt nghiệp
				</button>
				<!-- BỔ SUNG: Bộ lọc cho bảng Toàn khóa nằm ở đây -->
				<div class="md-table-actions no-print" style="margin-bottom: 15px; display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
					<div class="filter-group" style="display: flex; align-items: center; height: 36px; background: #fff; border: 1px solid #ccc; border-radius: 4px; position: relative;">
						<span style="background: #f8f9fa; height: 100%; display: flex; align-items: center; padding: 0 12px; border-right: 1px solid #ccc; font-weight: bold; font-size: 13px; color: #555;">
							Lọc tình trạng:
						</span>
						<div style="display: flex; gap: 15px; padding: 0 15px; align-items: center; font-size: 13px;">
							<label style="display: flex; align-items: center; gap: 5px; cursor: pointer;">
								<input type="checkbox" class="filter-status-tk" value="0" checked onchange="window.filterByStatusToanKhoa()"> Đang học
							</label>
							<label style="display: flex; align-items: center; gap: 5px; cursor: pointer;">
								<input type="checkbox" class="filter-status-tk" value="3" checked onchange="window.filterByStatusToanKhoa()"> Đã tốt nghiệp
							</label>
						</div>
					</div>
				</div>
			</div>

			<div class="table-responsive">
				<table class="md-table" id="tableStudyScore" style="width: 100%; border-collapse: collapse; font-family: Arial, sans-serif;">
					<thead>
						<tr style="background-color: #f8f9fa;">
							<th style="border: 1px solid #ddd; padding: 10px; width: 40px;">TT</th>
							<th style="border: 1px solid #ddd; padding: 10px; width: 100px;">Mã SV</th>
							<th style="border: 1px solid #ddd; padding: 10px; min-width: 180px;">Họ tên</th>
							<th style="border: 1px solid #ddd; padding: 10px;">Giới tính</th>
							<th style="border: 1px solid #ddd; padding: 10px;">Ngày sinh</th>
							<th style="border: 1px solid #ddd; padding: 10px;">Nơi sinh</th>
							<th style="border: 1px solid #ddd; padding: 10px;">Số môn đạt</th>
							<th style="border: 1px solid #ddd; padding: 10px;">Số t.chỉ học lại</th>
							<th style="border: 1px solid #ddd; padding: 10px;">Số môn thi lại</th>
							<th style="border: 1px solid #ddd; padding: 10px;">ĐTB chung tích lũy</th>
							<th style="border: 1px solid #ddd; padding: 10px;">ĐRL tích lũy</th>
							<th style="border: 1px solid #ddd; padding: 10px;">Xếp loại TN</th>                        
							<th style="border: 1px solid #ddd; padding: 8px; color: #d32f2f;">Ghi chú hạ bậc</th>
							<th style="border: 1px solid #ddd; padding: 8px;">Danh sách môn thi lại</th>
							<th style="border: 1px solid #ddd; padding: 8px;"> Danh sách môn chưa đạt</th>
							<th style="border: 1px solid #ddd; padding: 10px;">Trạng thái</th>
							
						</tr>
					</thead>
					<tbody>
						${res.data.map((sv, i) => {
							const isDungHan = sv.trang_thai === "Đủ ĐK Tốt nghiệp";
							// Lấy trạng thái tương tự bảng học kỳ (trả về số 0 hoặc 3)
							const stt = (sv.tinhtrang !== undefined) ? sv.tinhtrang : 0;
							
							return `
							<tr data-status-tk="${stt}" style="border-bottom: 1px solid #eee; background-color: ${isDungHan ? '#fff' : '#fff5f5'}">
								<td class="row-tt" style="border: 1px solid #ddd; text-align: center; padding: 8px;">${i + 1}</td>
								<td style="border: 1px solid #ddd; text-align: center; padding: 8px;">${sv.masv}</td>
								<td style="border: 1px solid #ddd; text-align: left; padding: 8px;"><b>${sv.hoten}</b></td>
								<td style="border: 1px solid #ddd; text-align: center; padding: 8px;">${sv.gioitinh === true || sv.gioitinh === 1 ? 'Nữ' : 'Nam'}</td>
								<td style="border: 1px solid #ddd; text-align: center; padding: 8px;">${formatNgaySinh(sv.ngaysinh)}</td>
								<td style="border: 1px solid #ddd; text-align: center; padding: 8px;">${sv.noisinh}</td>
								<td style="border: 1px solid #ddd; text-align: center; padding: 8px; ${sv.so_mon_dat.includes('/') && sv.so_mon_dat.split('/')[0] != sv.so_mon_dat.split('/')[1] ? 'color:red; font-weight:bold;' : ''}">
									${sv.so_mon_dat}
								</td>
								<td style="border: 1px solid #ddd; text-align: center; padding: 8px; ${Number(sv.ti_le_hoc_lai) > 0.10 ? 'color:red; font-weight:bold;' : ''}">
									${sv.ti_le_hoc_lai_text}
								</td>
								<td style="border: 1px solid #ddd; text-align: center; padding: 8px;">${sv.thi_lai}</td>
								<td style="border: 1px solid #ddd; text-align: center; padding: 8px; font-weight: bold; font-size: 1.1em;">${sv.gpa ? Number(sv.gpa).toFixed(2) : ''}</td>
								<td style="border: 1px solid #ddd; text-align: center; padding: 8px;">${sv.diem_rl}</td>
								<td style="border: 1px solid #ddd; text-align: center; padding: 8px;">${renderXepLoai(sv.xep_loai)}</td>                          
								<td style="border: 1px solid #ddd; text-align: left; font-style: italic; color: #e67e22; min-width: 150px;">
									${sv.ghi_chu_hb || ''}
								</td>
								<td style="border: 1px solid #ddd; text-align: left; color: #1976d2; font-size: 12px;">
									${sv.ds_mon_thi_lai || ''}
								</td>
								<td style="border: 1px solid #ddd; text-align: left; color: #dc3545; font-size: 12px;">
									${sv.ds_mon_chua_dat || ''}
								</td>
								<td style="border: 1px solid #ddd; text-align: center; padding: 8px;">
									<b style="color: ${isDungHan ? '#28a745' : '#dc3545'}">${sv.trang_thai}</b>
								</td>
							</tr>
						`}).join('')}
					</tbody>
				</table>
			</div>
		`;
		elResult.innerHTML = html;
		// Kích hoạt bộ lọc chạy ngay lần đầu tiên render
		window.filterByStatusToanKhoa();
	}

});

window.filterByStatus = function() {
    const table = document.getElementById('tableStudyScore');
    if (!table) return;
    
    // 1. Lấy danh sách các giá trị đang được chọn (ví dụ: ["0", "1"])
    const checkedBoxes = document.querySelectorAll('.filter-status:checked');
    const selectedValues = Array.from(checkedBoxes).map(cb => String(cb.value));
    
    const rows = table.querySelectorAll("tbody tr");
    let visibleIndex = 1;
    
    rows.forEach(tr => {
        const rowStatus = String(tr.getAttribute("data-status"));
        
        // 2. Nếu trạng thái của dòng nằm trong danh sách được chọn thì hiện
        if (selectedValues.includes(rowStatus)) {
            tr.style.display = "";
            const tdTT = tr.querySelector(".row-tt");
            if(tdTT) tdTT.innerText = visibleIndex++;
        } else {
            tr.style.display = "none";
        }
    });

    // Trường hợp không chọn ô nào thì ẩn hết hoặc có thể chỉnh để hiện hết tùy bạn
    if (selectedValues.length === 0) {
        // Có thể thông báo: "Vui lòng chọn ít nhất một tình trạng"
    }
};

window.filterByStatusToanKhoa = function() {
    const table = document.getElementById('tableStudyScore');
    if (!table) return;
    
    // 1. Lấy danh sách các giá trị đang được chọn từ checkbox Toàn khóa (ví dụ: ["0", "3"])
    const checkedBoxes = document.querySelectorAll('.filter-status-tk:checked');
    
    // Nếu không chọn ô nào thì ẩn toàn bộ dữ liệu bảng
    if (checkedBoxes.length === 0) {
        table.querySelectorAll("tbody tr").forEach(tr => tr.style.display = "none");
        return;
    }

    // Chuyển mảng các giá trị được chọn thành mảng các số nguyên [0, 3] để so sánh chuẩn với DB
    const selectedValues = Array.from(checkedBoxes).map(cb => parseInt(cb.value, 10));
    
    const rows = table.querySelectorAll("tbody tr");
    let visibleIndex = 1;
    
    rows.forEach(tr => {
        // Lấy giá trị từ attribute và chuyển ngay về kiểu Số nguyên (Int)
        const rowStatusAttr = tr.getAttribute("data-status-tk");
        const rowStatus = rowStatusAttr !== null ? parseInt(rowStatusAttr, 10) : 0;
        
        // 2. So sánh: Nếu trạng thái của dòng (kiểu số) nằm trong mảng được chọn (kiểu số) thì hiện
        if (selectedValues.includes(rowStatus)) {
            tr.style.display = "";
            const tdTT = tr.querySelector(".row-tt");
            if (tdTT) tdTT.innerText = visibleIndex++;
        } else {
            tr.style.display = "none";
        }
    });
};

window.exportToExcel = function() {
    // 1. Lấy bảng gốc và tạo một bản sao (clone) để không ảnh hưởng giao diện đang xem
    const originalTable = document.getElementById('tableStudyScore');
    const tempTable = originalTable.cloneNode(true);
    
    // 2. Xóa các dòng đang bị ẩn (display: none) trong bản sao
    // Việc này đảm bảo file Excel chỉ chứa dữ liệu đã lọc
    const rows = tempTable.querySelectorAll("tbody tr");
    rows.forEach(tr => {
        if (tr.style.display === 'none') {
            tr.remove();
        }
    });

    // 3. Lấy thông tin Lớp và Học kỳ để đặt tên file
    const elLop = document.getElementById('filter_lop_studyscore');
    const elHk = document.getElementById('filter_hk_studyscore');
    const tenLop = elLop.options[elLop.selectedIndex].text;
    const tenHk = elHk.options[elHk.selectedIndex].text;
    const fileName = `Bang diem Lop ${tenLop} ${tenHk}.xlsx`.replace(/[/\\?%*:|"<>]/g, '-');

    // 4. Chuyển bảng tạm thành Workbook
    // raw: true giúp giữ nguyên định dạng chuỗi (không tự đổi ngày tháng/số)
    const wb = XLSX.utils.table_to_book(tempTable, { raw: true });

    // 5. Duyệt qua tất cả các ô để ép kiểu chuỗi (Fix lỗi hiển thị ngày tháng)
    const ws = wb.Sheets[Object.keys(wb.Sheets)[0]];
    for (let cell in ws) {
        if (cell[0] === '!') continue;
        ws[cell].t = 's'; // Ép kiểu string
    }

    // 6. Xuất file
    XLSX.writeFile(wb, fileName);
};

function renderXepLoai(xepLoai) {
    if (!xepLoai) return "";

    const map = {
        "Xuất sắc": "badge-xuat-sac",
        "Giỏi": "badge-gioi",
        "Khá": "badge-kha",
        "Trung bình": "badge-trung-binh",
        "Yếu": "badge-yeu"
    };

    const cls = map[xepLoai] || "";

    return `<span class="badge-xl ${cls}">
                ${xepLoai}
            </span>`;
}

function thongKeXepLoai() {
    const rows = document.querySelectorAll("#tableStudyScore tbody tr");
    const stat = {
        total: 0,
        "Xuất sắc": 0, "Giỏi": 0, "Khá": 0, "Trung bình": 0, "Yếu": 0, "Kém": 0
    };

    rows.forEach(tr => {
        // QUAN TRỌNG: Chỉ thống kê nếu dòng đó KHÔNG bị ẩn bởi bộ lọc
        if (tr.style.display !== 'none') {
            const xlCell = tr.querySelector('.col-xeploai'); 
            const xl = xlCell ? xlCell.innerText.trim() : "";
            
            if (xl) {
                stat.total++;
                // Kiểm tra xem xếp loại có nằm trong danh mục không (tránh lỗi nếu có xếp loại lạ)
                if (stat[xl] !== undefined) {
                    stat[xl]++;
                }
            }
        }
    });
    return stat;
}

function thongKeTotNghiep() {
    const rows = document.querySelectorAll("#tableStudyScore tbody tr");
    const stat = {
        duDieuKien: 0,
        chuaDat: 0,
        "Xuất sắc": 0, "Giỏi": 0, "Khá": 0, "Trung bình": 0, "Yếu": 0
    };

    rows.forEach(tr => {
        // Chỉ thống kê các dòng đang được hiển thị sau khi lọc
        if (tr.style.display !== 'none') {
            
            // 1. Lấy tất cả các ô <td> trong dòng hiện tại
            const tds = tr.querySelectorAll("td");
            if (tds.length > 0) {
                // Ô cuối cùng (tds[tds.length - 1]) chính là cột Trạng thái hiển thị chữ "Đủ ĐK Tốt nghiệp" hoặc "Chưa đạt"
                const textTrangThai = tds[tds.length - 1].innerText.trim();
                
                // 2. Tiến hành đếm dựa trên chuỗi hiển thị thực tế trên giao diện công việc
                if (textTrangThai.includes("Đủ ĐK Tốt nghiệp")) {
                    stat.duDieuKien++;
                } else if (textTrangThai.includes("Chưa đạt")) {
                    stat.chuaDat++;
                }
            }

            // 3. Thống kê theo xếp loại bằng badge-xl như cũ
            const xlBadge = tr.querySelector('.badge-xl');
            const xl = xlBadge ? xlBadge.innerText.trim() : "";
            
            if (xl && stat[xl] !== undefined) {
                stat[xl]++;
            }
        }
    });
    return stat;
}

// Tạo Header cho trang in
function getPrintHeader(isToanKhoa = false) {
    const elLop = document.getElementById('filter_lop_studyscore');
    const elHk = document.getElementById('filter_hk_studyscore');
    const maHk = elHk.value;
    const lop = elLop.options[elLop.selectedIndex]?.text || "";
    const hk  = elHk.options[elHk.selectedIndex]?.text || "";
    const namhoc = hk.match(/\d{4}-\d{4}/)?.[0] || "";
	// Chuyển ký tự thứ 3 của mã học kỳ sang La Mã
    // const hkLaMa = (maHk.charAt(2) === '1') ? "I" : (maHk.charAt(2) === '2' ? "II" : maHk.charAt(2));
	
	const isNamHoc = /^\d{2}$/.test(maHk);

	const hkLaMa =
		maHk.charAt(2) === "1"
			? "I"
			: maHk.charAt(2) === "2"
				? "II"
				: maHk.charAt(2);

	let tieuDeChinh = "";

	if (isToanKhoa) {
		tieuDeChinh =
			"DANH SÁCH SINH VIÊN XÉT, CÔNG NHẬN TỐT NGHIỆP";
	}
	else if (isNamHoc) {
		tieuDeChinh =
			`BẢNG TỔNG HỢP KẾT QUẢ HỌC TẬP NĂM HỌC ${namhoc}`;
	}
	else {
		tieuDeChinh =
			`BẢNG ĐIỂM TỔNG KẾT HỌC KỲ ${hkLaMa}, NĂM HỌC ${namhoc}`;
	}
	
	// Biến đổi tiêu đề động dựa trên nút bấm
    // const tieuDeChinh = isToanKhoa 
    //     ? `DANH SÁCH SINH VIÊN XÉT, CÔNG NHẬN TỐT NGHIỆP` 
    //     : `BẢNG ĐIỂM TỔNG KẾT HỌC KỲ ${hkLaMa}, NĂM HỌC ${namhoc}`;
		
    return `
        <div style="text-align:center; margin-bottom:15px; font-family: 'Times New Roman'">
            <div style="font-weight:bold; font-size: 14px;">ỦY BAN NHÂN DÂN TỈNH CÀ MAU</div>
            <div style="font-weight:bold; font-size: 14px; text-decoration: underline;">
                TRƯỜNG CAO ĐẲNG NGHỀ VIỆT NAM - HÀN QUỐC CÀ MAU
            </div>
            <div style="margin-top:20px; font-weight:bold; font-size:16px">
                ${tieuDeChinh}
            </div>
            <div style="margin-top:5px; font-weight:bold; font-size: 15px">
                LỚP: ${lop.toUpperCase()}
            </div>
        </div>
    `;
}

// Tạo dòng thống kê dưới bảng
function getPrintSummary(isToanKhoa = false) {
    if (isToanKhoa) {
        const s = thongKeTotNghiep();
        return `
            <div style="margin-top:15px; font-family: 'Times New Roman'; font-size: 13px; line-height: 1.6; text-align: left;">
                <div style="font-weight: bold;">Điều kiện được công nhận tốt nghiệp: <span style="font-weight: normal;">Không có môn học, mô-đun chưa đạt và Điểm trung bình tích lũy toàn khóa (hệ 4) phải từ 2,00 trở lên.</span></div>
                <div style="font-weight: bold;">Trong đó:</div>
                <div style="color: red; font-weight: normal; padding-left: 5px;">
                    Được công nhận tốt nghiệp: ${s.duDieuKien}, Không được công nhận tốt nghiệp: ${s.chuaDat}
                </div>
                <div style="color: red; font-weight: normal; padding-left: 5px;">
                    Xếp loại tốt nghiệp: Xuất sắc: ${s["Xuất sắc"]}, Giỏi: ${s["Giỏi"]}, Khá: ${s["Khá"]}, Trung bình: ${s["Trung bình"]}
                </div>
            </div>
        `;
    }

    // Giữ nguyên logic cũ đối với in bảng điểm học kỳ bình thường
    const s = thongKeXepLoai();
    return `
        <div style="margin-top:10px; font-style:italic; font-family: 'Times New Roman'; font-size: 13px">
            * Tổng số: ${s.total} học sinh, sinh viên, trong đó 
            xếp loại Xuất sắc: ${s["Xuất sắc"]}, 
            Giỏi: ${s["Giỏi"]}, 
            Khá: ${s["Khá"]}, 
            Trung bình: ${s["Trung bình"]}, 
            Yếu: ${s["Yếu"]}.
        </div>
    `;
}

// Tạo Footer chữ ký
function getPrintFooter(isToanKhoa = false) {
    // Đổi chức danh dựa trên chế độ in
    const chucDanhDauTien = isToanKhoa ? "NV IN & RÀ SOÁT" : "LẬP BẢNG";

    return `
        <table class="print-footer-table" style="width:100%; margin-top:30px; text-align:center; border:none !important; font-family: 'Times New Roman'">
            <tr style="border:none !important">
                <td style="border:none !important; width: 33%"></td>
                <td style="border:none !important; width: 33%"></td>
                <td style="border:none !important; font-style:italic; font-size: 13px">
                    Cà Mau, ngày______tháng______năm 20______
                </td>
            </tr>
            <tr style="border:none !important">
                <td style="border:none !important; font-weight:bold; font-size: 13px; text-transform: uppercase;">${chucDanhDauTien}</td>
                <td style="border:none !important; font-weight:bold; font-size: 13px; text-transform: uppercase;">TRƯỞNG PHÒNG ĐÀO TẠO</td>
                <td style="border:none !important; font-weight:bold; font-size: 13px; text-transform: uppercase;">HIỆU TRƯỞNG</td>
            </tr>
            <tr style="border:none !important">
                <td colspan="3" style="height:80px; border:none !important"></td>
            </tr>
        </table>
    `;
}

function printBangDiem(isToanKhoa = false) {
    const tableElement = document.getElementById("tableStudyScore");
    if (!tableElement) {
        alert("Vui lòng tải dữ liệu trước khi in!");
        return;
    }
    
    const win = window.open("", "_blank", "width=1300,height=900");
    
    // Tạo nội dung trang in mới từ đầu để tránh bốc nguyên si lỗi HTML cũ
    win.document.write(`
        <html>
        <head>
            <title>${isToanKhoa ? 'In Danh Sách Xét Tốt Nghiệp' : 'In Bảng Điểm'}</title>
            <style>
                @page { size: A4 landscape; margin: 10mm; }
                body { font-family: "Times New Roman", serif; margin: 0; padding: 0; }
                table { width: 100%; border-collapse: collapse; margin-top: 15px; }
                th, td { border: 1px solid #000 !important; padding: 6px 4px; text-align: center; font-size: 11px; }
                th { background-color: #f2f2f2 !important; -webkit-print-color-adjust: exact; font-weight: bold; }
                b { font-weight: bold; }
                
                /* Ẩn các dòng bị bộ lọc ẩn ở giao diện chính khi in */
                tr[style*="display: none"], tr[style*="display:none"] {
                    display: none !important;
                }
                
                /* Loại bỏ viền cho table footer (phần chữ ký) */
                .print-footer-table, .print-footer-table td { border: none !important; }
            </style>
        </head>
        <body> 
            ${getPrintHeader(isToanKhoa)}
            
            <div class="print-table-container">
                ${tableElement.outerHTML}
            </div>
            
            ${getPrintSummary(isToanKhoa)}
            ${getPrintFooter(isToanKhoa)}
        </body>
        </html>
    `);
    
    win.document.close();

    // Chờ một chút để trình duyệt nạp và render lại bảng chuẩn chỉnh rồi mới ra lệnh in
    setTimeout(function() {
        win.focus();
        win.print();
        win.close();
    }, 300); 
}

async function openEditCTDT() {
    const maL = document.getElementById('filter_lop_studyscore').value;
    if (!maL) return alert("Vui lòng chọn lớp!");

    // 1. Lấy danh sách Học kỳ từ bộ lọc (filter) hiện có trên giao diện
    const filterHK = document.getElementById('filter_hk_studyscore'); 
    if (!filterHK) {
        console.error("Không tìm thấy bộ lọc filter_hk_studyscore");
        return;
    }
    
    // Tạo mảng các học kỳ để dùng cho Dropdown trong Modal
    const listHK = Array.from(filterHK.options)
        .filter(opt => opt.value !== "") // Loại bỏ option rỗng/mặc định
        .map(opt => ({ value: opt.value, text: opt.text }));

    // 2. Gọi API lấy dữ liệu CTĐT từ Flask (sử dụng code bạn vừa cung cấp)
    try {
        const response = await fetch('/api/get_ctdt_lop', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ MaL: maL })
        });
        const result = await response.json();

        if (!result.success) throw new Error(result.message);

        // 3. Xây dựng Modal
        let modalHtml = `
            <div id="modalCTDT" class="md-modal">
                <div class="md-modal-content" style="width: 650px; max-width: 95%;">
                    <div class="modal-header">
                        <h4 style="margin:0;"><i class="fas fa-layer-group"></i> Chương trình đào tạo - Lớp ${maL}</h4>
                    </div>
                    <div class="modal-body" style="max-height: 450px; overflow-y: auto;">
                        <table class="md-table">
                            <thead>
                                <tr style="background: #f8f9fa;">
                                    <th>Mã HP</th>
                                    <th>Tên học phần</th>
                                    <th style="width: 150px;">Học kỳ</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${result.data.map(item => {
                                    // Tạo dropdown chọn học kỳ
                                    let selectHtml = `<select class="edit-hk-select" data-mahp="${item.MaHP}" style="width:100%; padding:5px; border-radius:4px;">`;
                                    listHK.forEach(hk => {
                                        // 🔥 SỬA: So sánh hk.value (mã học kỳ ở thẻ select) với item.MaHK (mã học kỳ từ DB trả về)
                                        const isSelected = (hk.value === item.MaHK) ? 'selected' : '';
                                        selectHtml += `<option value="${hk.value}" ${isSelected}>${hk.text}</option>`;
                                    });
                                    selectHtml += `</select>`;

                                    return `
                                        <tr>
                                            <td style="font-size:11px; color:#666;">${item.MaHP}</td>
                                            <td style="text-align:left;"><b>${item.Hocphan}</b> <small>(${item.Sotinchi} TC)</small></td>
                                            <td>${selectHtml}</td>
                                        </tr>
                                    `;
                                }).join('')}
                            </tbody>
                        </table>
                    </div>
                    <div class="modal-footer" style="text-align: right; border-top: 1px solid #eee; padding-top: 15px;">
                        <button class="md-btn-save" onclick="submitUpdateCTDT('${maL}')">Lưu thay đổi</button>
                        <button class="md-btn-cancel" onclick="document.getElementById('modalCTDT').remove()">Đóng</button>
                    </div>
                </div>
            </div>
        `;
        document.body.insertAdjacentHTML('beforeend', modalHtml);
    } catch (err) {
        alert("Lỗi tải dữ liệu: " + err.message);
    }
}

async function submitUpdateCTDT(maL) {
    // 1. Lấy dữ liệu từ các dropdown trong Modal
    const updates = Array.from(document.querySelectorAll('.edit-hk-select')).map(sel => ({
        MaHP: sel.dataset.mahp,
        MaHK: sel.value 
    }));

    try {
        const response = await fetch('/api/update_ctdt_hocky', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ MaL: maL, updates: updates })
        });

        const res = await response.json();
        
        if (res.success) {
            alert("Cập nhật CTĐT thành công!");
            
            // 2. Đóng modal
            const modal = document.getElementById('modalCTDT');
            if (modal) modal.remove();

            // 3. Render lại bảng bằng cách gọi lại loadDiem với thông số hiện tại
            const currentLop = document.getElementById('filter_lop_studyscore').value;
            const currentHk = document.getElementById('filter_hk_studyscore').value;

            // 3. Gọi hàm loadDiem (bây giờ đã nhận dạng được vì là global)
            if (currentLop && currentHk) {
                window.loadDiem(currentLop, currentHk);
            }
        } else {
            alert("Lỗi cập nhật: " + res.message);
        }
    } catch (err) {
        alert("Lỗi kết nối API: " + err.message);
    }
}

function saveHocky() {
	
	const btn = document.getElementById("btnSaveHocKy");
    const text = btn.querySelector(".btn-text");
    const spinner = btn.querySelector(".btn-spinner");
	
	// bật trạng thái loading
    btn.disabled = true;
    text.style.display = "none";
    spinner.style.display = "inline-block";// bật trạng thái loading
    btn.disabled = true;
    text.style.display = "none";
    spinner.style.display = "inline-block";

    if (!currentHocKyData.length) {
        alert("Không có dữ liệu để lưu.");
        return;
    }

    if (!confirm("Xác nhận lưu tổng kết học kỳ?")) {
        return;
    }
	
	const payload = currentHocKyData.map(sv => ({
		id: sv.id,
		dtb: sv.dtb,               // -> DTB
		dhb: sv.dhb,               // -> DTBHB
		DTBTLBon: sv.DTBTLBon,     // giữ nguyên
		SotinchiTL: sv.SotinchiTL,
		SotinchiDat: sv.SotinchiDat,
		KQxetHV: sv.KQxetHV,
		GhichuKQxetHV: sv.GhichuKQxetHV,
		diem_rl: sv.diem_rl,
		xl_ht: sv.xl_ht,
		xl_hb: sv.xl_hb,
		xl_tl: sv.xl_tl,
		thi_lai: sv.thi_lai
	}));

    fetch('/api/diem/save_hocky', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            MaHK: currentMaHK,
            data: payload
        })
    })
    .then(res => {
		if (!res.ok) throw new Error("Lỗi server");
		return res.json();
	})
    .then(res => {
        if (res.success) {
            alert("Đã lưu tổng kết học kỳ thành công.");
        } else {
            alert("Lỗi khi lưu: " + (res.message || ""));
        }
    })
    .catch(err => {
        console.error(err);
        alert("Có lỗi xảy ra khi lưu.");
    })
	.finally(() => {
        // tắt loading
        btn.disabled = false;
        text.style.display = "inline-block";
        spinner.style.display = "none";
    });
}

async function saveNamHoc() {
    const btn = document.getElementById("btnSaveNamHoc");

    if (!btn) {
        alert("Không tìm thấy nút lưu năm học.");
        return;
    }

    const text = btn.querySelector(".btn-text");
    const spinner = btn.querySelector(".btn-spinner");

    if (!currentMaNH || !/^\d{2}$/.test(currentMaNH)) {
        alert("Mã năm học không hợp lệ.");
        return;
    }

    if (!Array.isArray(currentNamHocData) || !currentNamHocData.length) {
        alert("Không có dữ liệu năm học để lưu.");
        return;
    }

    if (!confirm(`Xác nhận lưu tổng kết năm học ${currentMaNH}?`)) {
        return;
    }

    btn.disabled = true;
    text.style.display = "none";
    spinner.style.display = "inline-block";

    const payload = currentNamHocData.map(sv => ({
        id: sv.id,
        diem_rl: sv.diem_rl,
        diem_rl_tl: sv.diem_rl_tl,
        dtb1: sv.dtb1,
        dtb: sv.dtb,
        dhb: sv.dhb,
        xl_ht: sv.xl_ht,
        xl_hb: sv.xl_hb,
        thi_lai: sv.thi_lai,
        SotinchiDat: sv.SotinchiDat
    }));

    try {
        const response = await fetch("/api/diem/save_nam_hoc", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                MaNH: currentMaNH,
                data: payload
            })
        });

        let result;

        try {
            result = await response.json();
        } catch {
            throw new Error(
                `API không trả về JSON hợp lệ. HTTP ${response.status}`
            );
        }

        if (!response.ok || result.success === false) {
            throw new Error(
                result.message ||
                result.error ||
                "Không thể lưu điểm năm học."
            );
        }

        alert(
            result.message ||
            "Đã lưu tổng kết năm học thành công."
        );

    } catch (error) {
        console.error("Lỗi saveNamHoc:", error);
        alert(`Lỗi lưu năm học: ${error.message}`);
    } finally {
        btn.disabled = false;
        text.style.display = "inline-block";
        spinner.style.display = "none";
    }
}

async function xettotnghiep(btn) {

    const maL = document.getElementById('filter_lop_studyscore').value;
    if (!maL) {
        alert("Vui lòng chọn lớp!");
        return;
    }

    if (!confirm("Xác nhận xét và công nhận tốt nghiệp?")) return;
	
	// 🔒 Disable nút ngay khi bắt đầu
    btn.disabled = true;
    const originalText = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang xử lý...';

    try {
        const res = await fetch('/api/diem/xet-tot-nghiep', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ lop: maL })
        });

        const data = await res.json();

        if (data.success) {
            alert(data.message || "Đã xét tốt nghiệp thành công!");
            
            // Reload lại bảng toàn khóa
            window.loadDiem(maL, 'TK');
        } else {
            alert("Lỗi: " + data.message);
        }

    } catch (err) {
        alert("Lỗi kết nối server.");
        console.error(err);
    } finally {
        // 🔓 Luôn bật lại nút dù thành công hay lỗi
        btn.disabled = false;
        btn.innerHTML = originalText;
    }
}

async function congnhantotnghiep() {

    const maL = document.getElementById('filter_lop_studyscore').value;
    if (!maL) {
        alert("Vui lòng chọn lớp!");
        return;
    }

    const modal = new bootstrap.Modal(
        document.getElementById('modalCongNhan')
    );

    modal.show();    
 
	// Load danh sách học kỳ
	await loadHocKy();
	
	// Load danh sách quyết định
    await loadQuyetDinhTN();
	
	// Load sinh viên đủ điều kiện
    await loadSinhVienTotNghiep(maL);
}

function formatDateVN(dateStr) {
    if (!dateStr) return "";
	const d = new Date(dateStr);
	return d.toLocaleDateString('vi-VN');
}

async function loadQuyetDinh() {
    const res = await fetch("/api/quyetdinh-totnghiep");
    listQuyetDinh = await res.json();
}

async function loadHocKy() {
    const res = await fetch("/api/hocky");
    listHocKy = await res.json();
}

function renderHocKyOptions(selected) {

    let html = `<option value="">--Chọn--</option>`;

    listHocKy.forEach(hk => {

        const sel = (selected && hk.MaHK == selected) ? "selected" : "";

        html += `
            <option value="${hk.MaHK}" ${sel}>
                ${hk.Hocky}
            </option>
        `;
    });

    return html;
}

function renderQuyetDinhOptions(selectedMaQDTN) {

    let html = '<option value="">--Chọn--</option>';

    listQuyetDinh.forEach(qd => {
        const selected = qd.MaQDTN == selectedMaQDTN ? "selected" : "";
        html += `
            <option value="${qd.MaQDTN}" ${selected}>
                ${qd.So}
            </option>
        `;
    });

    return html;
}

async function loadQuyetDinhTN() {
    const select = document.getElementById("selectQDTN");

    select.innerHTML = '<option value="">Đang tải...</option>';

    const res = await fetch('/api/quyetdinh-totnghiep');
    const data = await res.json();

    select.innerHTML = '<option value="">-- Chọn quyết định --</option>';

    data.forEach(qd => {
        select.innerHTML += `
            <option value="${qd.MaQDTN}" >
                ${qd.So} - ${formatDateVN(qd.Ngayky)} - ${qd.Noidung}
            </option>
        `;
    });
}

async function loadSinhVienTotNghiep(maL) {

    const tbody = document.getElementById("tableSinhVienTN");
    tbody.innerHTML = "";

    const res = await fetch(`/api/sinhvien-totnghiep/${maL}`);
    const data = await res.json();

    if (!data.length) {
        tbody.innerHTML = `<tr>
            <td colspan="9" class="text-center text-danger">
                Không có sinh viên đủ điều kiện
            </td>
        </tr>`;
        return;
    }

    data.forEach((sv, index) => {

        tbody.innerHTML += `
        <tr>
            <td class="text-center">
                <input type="checkbox" class="chk-sv">
            </td>

            <td class="text-center">${index + 1}</td>

            <td class="masv">${sv.MaSV}</td>
			
            <td>${sv.Hoten}</td>

            <td>
                <input type="text" class="form-control sovaoso"
                       value="${sv.Sovaoso || ''}">
            </td>

            <td>
                <input type="text" class="form-control sohieu"
                       value="${sv.Sohieu || ''}">
            </td>

            <!-- QĐTN readonly -->
            <td>
				<input type="text" class="form-control"
					   value="${sv.SoQD ? sv.SoQD + ' - ' + formatDateVN(sv.Ngayky) : ''}"
					   readonly>
			</td>

            <!-- Học kỳ -->
            <td>
                <select class="form-select mahktn">
                    ${renderHocKyOptions(sv.MaHKTN)}
                </select>
            </td>

            <!-- Thao tác -->
            <!-- Thao tác -->
			<td class="text-center">

				<!-- In GCN tốt nghiệp -->
				<i class="fa-solid fa-award text-primary me-2"
				   style="cursor:pointer"
				   title="In Giấy chứng nhận tốt nghiệp"
				   onclick="inGiayTam('${sv.MaSV}')">
				</i>

				<!-- In bảng điểm tốt nghiệp -->
				<i class="fa-solid fa-file-lines text-success"
				   style="cursor:pointer"
				   title="In Bảng điểm tốt nghiệp"
				   onclick="inBangDiem('${sv.MaSV}')">
				</i>

			</td>
        </tr>
        `;
    });
}

function openQuyetDinhModal() {

    const select = document.getElementById("selectQDTN");

    if (!select) {
        console.error("Không tìm thấy selectQDTN trong DOM");
        return;
    }

    const maQDTN = select.value;

    const modal = new bootstrap.Modal(
        document.getElementById("modalQuyetDinhTN")
    );

    if (!maQDTN) {

        document.getElementById("qdModalTitle").innerText = "Thêm Quyết định TN";

        fetch("/api/quyetdinh-next-id")
            .then(res => res.json())
            .then(data => {
                document.getElementById("qd_MaQDTN").value = data.MaQDTN;
            });

        document.getElementById("qd_So").value = "";
        document.getElementById("qd_Ngayky").value = "";
        document.getElementById("qd_Nguoiky").value = "";
        document.getElementById("qd_Noidung").value = "";

    } else {

        document.getElementById("qdModalTitle").innerText = "Sửa Quyết định TN";

        fetch(`/api/quyetdinh/${maQDTN}`)
            .then(res => res.json())
            .then(data => {
                document.getElementById("qd_MaQDTN").value = data.MaQDTN;
                document.getElementById("qd_So").value = data.So;
                document.getElementById("qd_Ngayky").value = data.Ngayky;
                document.getElementById("qd_Nguoiky").value = data.Nguoiky;
                document.getElementById("qd_Noidung").value = data.Noidung;
            });
    }

    modal.show();
}

function saveQuyetDinhTN() {

    const data = {
        MaQDTN: document.getElementById("qd_MaQDTN").value,
        So: document.getElementById("qd_So").value,
        Ngayky: document.getElementById("qd_Ngayky").value,
        Nguoiky: document.getElementById("qd_Nguoiky").value,
        Noidung: document.getElementById("qd_Noidung").value
    };

    fetch("/api/quyetdinh-save", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
    })
    .then(res => res.json())
    .then(res => {

        if (res.success) {

            alert("Lưu thành công");
			
			// 1️⃣ Đóng modal phụ
			const modal = bootstrap.Modal.getInstance(
				document.getElementById("modalQuyetDinhTN")
			);
			modal.hide();

			// 2️⃣ Load lại dropdown trong modal chính
			loadQuyetDinhDropdown(() => {
				document.getElementById("selectQDTN").value =
					document.getElementById("qd_MaQDTN").value;
			});

        } else {
            alert("Lỗi: " + res.message);
        }

    });
}

function loadQuyetDinhDropdown(callback) {

    fetch("/api/quyetdinh-totnghiep")
        .then(res => res.json())
        .then(data => {

            const select = document.getElementById("selectQDTN");
            select.innerHTML = '<option value="">-- Chọn quyết định --</option>';

            data.forEach(qd => {
                select.innerHTML += `<option value="${qd.MaQDTN}">
                    ${qd.So} - ${formatDateVN(qd.Ngayky)} - ${qd.Noidung}
                </option>`;
            });

            if (callback) callback();
        });
}

async function luuCongNhanTotNghiep() {

    const maQDTN = document.getElementById("selectQDTN").value;
    if (!maQDTN) {
        alert("Vui lòng chọn quyết định!");
        return;
    }

    const rows = document.querySelectorAll("#tableSinhVienTN tr");

    let danhSach = [];

    rows.forEach(row => {

        const checkbox = row.querySelector(".chk-sv");

        if (checkbox && checkbox.checked) {

            danhSach.push({
                MaSV: row.querySelector(".masv").innerText,
                Sovaoso: row.querySelector(".sovaoso").value,
                Sohieu: row.querySelector(".sohieu").value,
                MaHKTN: row.querySelector(".mahktn").value
            });
        }
    });

    if (!danhSach.length) {
        alert("Chưa chọn sinh viên nào!");
        return;
    }
	
	if (!confirm("Xác nhận công nhận tốt nghiệp?")) return;

    try {

        setLoadingButton(true);   // 🔥 BẬT loading

        const res = await fetch("/api/congnhan-totnghiep", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                MaQDTN: maQDTN,
                sinhvien: danhSach
            })
        });

        const result = await res.json();

        if (result.success) {
            alert("Lưu thành công!");
			bootstrap.Modal.getInstance(
				document.getElementById('modalCongNhan')
			).hide();

			window.loadDiem(
				document.getElementById('filter_lop_studyscore').value,
				'TK'
			);
				
			} else {
				alert(result.message);
			}

    } catch (err) {

        alert("Có lỗi xảy ra!");
        console.error(err);

    } finally {

        setLoadingButton(false);  // 🔥 LUÔN bật lại nút
    }
}

function setLoadingButton(isLoading) {

    const btn = document.getElementById("btnLuu");
    const text = document.getElementById("btnLuuText");
    const spinner = document.getElementById("btnLuuSpinner");

    if (isLoading) {
        btn.disabled = true;
        text.innerText = "Đang lưu...";
        spinner.classList.remove("d-none");
    } else {
        btn.disabled = false;
        text.innerText = "💾 Lưu";
        spinner.classList.add("d-none");
    }
}

function inGiayTam(maSV) {
    window.open(`/giaytam/${maSV}`,
        "_blank",
        "width=800,height=900");
}

function inBangDiem(maSV) {
    window.open(`/bangdiem/${maSV}`,
        "_blank",
        "width=800,height=900");
}
